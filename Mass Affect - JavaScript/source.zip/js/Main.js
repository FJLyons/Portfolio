var app = null;
var barTime;

function main()
{
	console.log("main")
	app = new App();
	
}