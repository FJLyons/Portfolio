var app = null;
var barTime;
var canvas, ctx;

function main()
{
	console.log("main")
	app = new App();
}